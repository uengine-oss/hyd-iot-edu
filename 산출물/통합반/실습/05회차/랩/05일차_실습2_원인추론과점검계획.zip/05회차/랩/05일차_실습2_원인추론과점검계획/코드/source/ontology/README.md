# 공용 온톨로지 읽는 법

이 폴더의 두 파일은 HYD 유압 파워팩의 공용 온톨로지 가운데 설비 진단에 쓰는 부분이다.

| 파일 | 내용 |
|---|---|
| `schema.json` | 클래스 11개와 관계 16개의 정의. 어떤 종류의 노드가 있고 무엇과 무엇이 이어질 수 있는지를 정한다 |
| `graph.json` | 그 정의에 따라 적은 노드 83개(`nodes`)와 관계 136개(`rels`) |

## graph.json의 모양
- 노드 한 건: `{"labels": ["Cause"], "props": {"id": "cause:cooler-fin-fouling", "name": "쿨러 핀 오염", ...}}`
- 관계 한 건: `{"type": "CAUSES", "a": "cause:cooler-fin-fouling", "b": "fm:cooler-performance-loss", "props": {}}`. `a`에서 `b`로 가는 방향이다.
- 식별자의 접두사가 클래스를 드러낸다: `asset:` 설비, `comp:` 구성 요소, `sen:` 센서, `sv:` 상태 변수, `pattern:` 이상 패턴, `sym:` 증상, `fm:` 고장 유형, `cause:` 원인, `evd:` 증거, `skill:` 조치 방법, `role:` 역할.

## 경보에서 원인과 조치까지 가는 길
```
이상 패턴 ─DETECTS→ 증상 ─INDICATES→ 고장 유형 ←CAUSES─ 원인 ─EVIDENCED_BY→ 증거
                      │                  │
                 OBSERVED_BY        MITIGATED_BY (즉시 완화) · REMEDIED_BY (근본 조치)
                      ↓                  ↓
                    센서              조치 방법 ─ADDRESSES→ 원인 (특정 원인에만 맞을 때)
                                         └─APPROVED_BY→ 역할
```
- 경보에는 이상 패턴의 코드(`code`, 예: `COOLER_DEGRADATION`)가 붙어 온다.
- 그래프가 알려 주는 것은 후보까지다. 후보 가운데 어느 것이 맞는지는 증거의 기준에 센서 값을 대어 보아야 정해진다.

## 증거 한 건을 읽는 법
`{"id": "evd:fin-fouling-ce-low", "name": "최근 30초 냉각 효율 평균 70 % 미만", "rule": "avg(CE) over 30s < 70", "tag": "CE", "aggregate": "avg", "windowSeconds": 30, "expect": "lt", "threshold": 70, "section": "HM-8.4"}`

| 속성 | 뜻 |
|---|---|
| `tag` | 읽을 태그 |
| `aggregate` | 구간의 값을 하나로 줄이는 방법. `avg`는 평균, `max-min`은 최댓값에서 최솟값을 뺀 폭 |
| `windowSeconds` | 판단하는 시각에서 거슬러 올라가는 구간의 길이(초) |
| `expect` · `threshold` | 비교 방향과 기준값. `lt` 미만, `gt` 초과, `gte` 이상 |
| `rule` | 같은 조건을 사람이 읽도록 적은 것. 실행하지 않는다 |
| `section` | 이 증거를 정한 매뉴얼 절. 없는 증거도 있다 |

## 조치 방법 한 건을 읽는 법
조치 방법(Skill) 하나가 SOP 하나다. `sopId`가 절차 번호이고, `steps`에 단계가 순서대로 들어 있다. 단계마다 `section`이 근거 매뉴얼 절이다. `kind`가 `control`이면 설비 제어이고 `work_order`이면 정비 작업지시다. 승인 역할은 `APPROVED_BY` 관계로 이어져 있다.

## 알아 둘 것
- 원인의 `prior`는 사전 확률이다. 값을 읽기 전에 그 원인이 얼마나 흔한지를 나타낸다.
- 캐비닛 온도 태그 `TS4`는 증거가 쓰지만 센서 노드로는 등록되어 있지 않다.
- 작동유 열화(`fm:oil-degradation`)의 원인 넷에는 증거가 등록되어 있지 않다. 실시간 센서가 없고 정기 오일 분석 결과를 사람이 입력하기 때문이다.
- 과열 정지 · 저압 정지 · 고진동 정지는 앞선 고장이 이어진 결과여서(`LEADS_TO`) 자체 원인이 등록되어 있지 않다.
- 조치 방법 가운데 승인 역할이 이어지지 않은 것이 있다(`SOP-FAN-11`, `SOP-FAN-12`).
