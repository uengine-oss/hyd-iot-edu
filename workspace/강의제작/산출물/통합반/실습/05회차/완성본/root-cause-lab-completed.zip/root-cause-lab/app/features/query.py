from datetime import datetime, timedelta

def instructions(request):
    return '''원인 후보는 그래프의 Cause에서 모두 읽되, 문서의 사전 확률을 관측 증거로 바꾸지 않는다.
현재 적용되는 Knowledge의 출처와 문서 목록의 판본 상태를 조회한다. HM-8.4 조건과 원문 주변 절,
작업 전 안전 조건, 해당 설비의 사건·정비 이력을 함께 확인한다. 그래프에서 찾지 못한 연결은 원문으로 보완하고 연결이 있다고 만들지 않는다.
HM-8.3의 26줄 부하90% 운전 전제를 원문으로 확인한다. 후보 관측은 RUN·부하90%로 조회하고, 현재 운전 이력도 함께 확인한다.
Knowledge의 채택·현행 판과 STATED_IN으로 이어지는 실제 원문 절·줄을 반환받는다. 없는 관계를 추가하지 않는다.
관측은 요청 기준시각에서 끝나는 1초 자료로 CE 최근30초, VS1·TS4 최근120초, TS1 최근60초를 각각 집계한다.
현재값뿐 아니라 같은 설비의 다른 날짜 장기 10초 자료에서 같은 운전 상태·부하를 골라 비교한다. 기간/상태가 다르면 같은 근거로 합치지 않는다.
표본 수, 최대 공백, 마지막 관측시각, 수집 품질을 확인한다. 관측이 없거나 질의가 실패하면 숫자를 채우지 않는다.
정비 완료 메모와 정비 상태는 구별한다. 이번 결과는 정비 담당자가 검토할 점검 제안이며 실제 정지·LOCAL·동력 잠금을 확인했다는 뜻이 아니다.
필요한 근거를 조회한 뒤 finish에 요약과 사용한 T번호를 쓴다. 도구 이름과 인수는 매 단계 현재까지의 반환 내용을 보고 정한다.'''

def prepare_query(name, arguments, request):
    args = dict(arguments)
    if name in ['observations', 'history']:
        # 요청과 다른 설비의 증거가 섞이지 않게 하되 비교 요청 자체는 별도 실행한다.
        args['asset'] = request['asset']
        if datetime.fromisoformat(args['end'].replace('Z', '+00:00')) > datetime.fromisoformat(request['as_of']):
            args['end'] = request['as_of']
    if name == 'observations' and args.get('dataset', '1s') == '1s':
        args['state'] = 'RUN'
        args['load_pct'] = 90
    if name == 'document' and args.get('doc_id') == 'HM-8':
        # 숫자가 든 한 줄만 선택해도 표의 적용 조건과 같은 절의 예외를 함께 받는다.
        args['revision'] = '1.1'
        if not args.get('section') and args.get('line_start'):
            line = int(args['line_start'])
            ranges = [(7,15,'HM-8.1'),(16,24,'HM-8.2'),(25,34,'HM-8.3'),(35,43,'HM-8.4'),(44,69,'HM-8.5'),(70,72,'HM-8.6'),(73,85,'HM-8.7'),(86,89,'HM-8.8')]
            for begin, end, section in ranges:
                if begin <= line <= end:
                    args['section'] = section
                    args.pop('line_start',None); args.pop('line_end',None); break
    return args