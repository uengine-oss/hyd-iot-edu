# 제공 빈 틀 — 기준 단위와 빈 단위 칸을 정하는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.


def base_unit(quantity, units):
    """근거: 그 물리량에서 원자료가 가장 많이 쓴 단위(같은 수면 센서 목록에서 먼저 나온 것)."""
    return max(units, key=lambda u: (units.count(u), -units.index(u)))


def blank_unit(row, candidates):
    """근거: 같은 모델 · 같은 태그 · 같은 정상값 · 한계 · 한계구분의 줄이 단위 하나를 말할 때만 그 단위, 아니면 미확인(짐작하지 않음)."""
    key = ('모델', '태그', '정상값', '한계', '한계구분')
    same = {c['단위'] for c in candidates if all(c[k] == row[k] for k in key)}
    return same.pop() if len(same) == 1 else '미확인'
