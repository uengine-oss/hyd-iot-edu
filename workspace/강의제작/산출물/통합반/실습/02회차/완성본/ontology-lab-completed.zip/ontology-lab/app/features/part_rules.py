# 제공 빈 틀 — 교체 부품을 잇는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.


def applies(model, text):
    """예비품 목록 적용모델 칸 — 「전 모델」, 「HPP-45A」, 「HPP-45A·45B」 꼴."""
    if text == '전 모델':
        return True
    head, *rest = text.split('·')
    prefix = head.rsplit('-', 1)[0] + '-'
    return model in [head, *[prefix + x for x in rest]]


def find_part(cell, asset, component, spares, cross, same_component, same_model):
    """components.csv의 교체부품 칸을 제공 코드가 바로 풀지 못한 행(빈칸 · 품명 · 짧은 표기)에서 부른다.
    근거: spare_parts.csv의 적용모델 · 쓰는곳 — 같은 모델의 같은 구성 요소에 쓰는 예비품이 하나면 그것. 둘 이상이면 같은 모델의 다른 설비가 그 자리에 품번으로 적은 것이 그 가운데 하나를 가리킬 때만 그것(같은 모델은 같은 부품을 씀)."""
    hits = sorted(s['품번'] for s in spares if applies(asset['모델'], s['적용모델']) and same_component(s['쓰는곳']))
    if len(hits) == 1:
        return hits[0]
    used = sorted({m['품번'] for m in same_model if m['품번'] in hits})
    return used[0] if len(used) == 1 else None


def same_item(maker_code, internal_codes):
    """근거: 현장 메모 41행(3라인 자재는 따로 등록, 합칠지 검토 중), supply_terms.csv의 두 품번 견적(공급사 · 단가가 다름), part_aliases.csv의 같은 제조사 품번 줄."""
    return False
