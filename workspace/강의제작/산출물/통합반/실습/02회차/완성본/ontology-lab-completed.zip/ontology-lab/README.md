﻿# 온톨로지 설계 · 완성본

AI 계정이 없거나 구현 중 막혔을 때 실행해 보는 묶음입니다. 판단 기준 한 가지를 적용했으며 선택과 근거는 app/features/decisions.csv에 있습니다.

```text
data/           실습 자료
app/features/   AI와 구현할 핵심 기능
app/ui/         결과 화면 — 제공
app/utils/      공통 처리 — 제공
output/         실행 후 생기는 결과
AGENTS.md       AI가 지킬 공통 규칙
```

실행: `python run.py parts
python run.py query`
