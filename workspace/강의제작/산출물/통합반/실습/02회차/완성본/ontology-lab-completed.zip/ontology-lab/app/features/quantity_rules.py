# 제공 빈 틀 — 같은 물리량을 가르는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.


def common_name(members):
    """묶음에서 가장 많이 쓴 재는것(같은 수면 센서 목록에서 먼저 나온 것)."""
    names = [m['재는것'] for m in members]
    return max(names, key=lambda n: (names.count(n), -names.index(n)))


def same_quantity(a, b):
    """근거: 붙은 자리까지 같아야 같은 물리량 — 세 대는 같은 자리의 센서에 같은 태그를 쓴다(현장 메모 24행)."""
    return a['태그'] == b['태그']


def quantity_name(members):
    """근거: 묶음에서 가장 많이 쓴 재는것 — 붙은 자리를 가리키는 이름(유온 · 쿨러 출구 유온 · 탱크 유온)."""
    return common_name(members)
