# 제공 빈 틀 — 같은 물리량을 가르는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.


def value_kind(row):
    """재는 값의 종류(무엇의 어떤 값) — 재는것 이름에 든 말로 가른다. 작동유의 온도 · 압력 · 유량과, 따로 재는 냉각수 유량
    (현장 메모 20행) · 필터 차압 · 진동은 다른 종류다."""
    what = row['재는것']
    for word, kind in (('냉각수', '냉각수 유량'), ('차압', '차압'), ('온도', '작동유 온도'), ('유온', '작동유 온도'),
                       ('압력', '작동유 압력'), ('유량', '작동유 유량'), ('진동', '진동')):
        if word in what:
            return kind
    return what


def common_name(members):
    """묶음에서 가장 많이 쓴 재는것(같은 수면 센서 목록에서 먼저 나온 것)."""
    names = [m['재는것'] for m in members]
    return max(names, key=lambda n: (names.count(n), -names.index(n)))


def local_gauge(row):
    """통신 없이 손으로 읽는 현장 지시계 — SCADA 태그가 없다(현장 메모 27행)."""
    return '현장 지시' in row['센서명']


def same_quantity(a, b):
    """근거: 붙은 자리까지 같아야 같은 물리량. HPP-45A · 45B는 같은 자리의 센서에 같은 태그를 쓰므로(현장 메모 27행)
    종류와 태그가 같으면 같은 자리다(HYD-04의 FS2는 태그가 같아도 냉각수 유량이라 다르다). 태그가 없는 현장 지시계는 종류와 붙은 구성 요소의 계통이
    같은 센서와 같은 자리로 본다(탱크의 유온계는 탱크 유온, 펌프의 압력계는 토출 압력)."""
    if value_kind(a) != value_kind(b):
        return False
    if local_gauge(a) == local_gauge(b):
        return a['태그'] == b['태그']
    return a['계통'] == b['계통']


def quantity_name(members):
    """근거: 묶음에서 가장 많이 쓴 재는것 — 붙은 자리를 가리키는 이름(유온 · 쿨러 출구 유온 · 탱크 유온)."""
    return common_name(members)
