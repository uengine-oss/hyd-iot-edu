# 제공 빈 틀 — 같은 물리량과 센서 종류를 가르는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.
import re

NAMES = {'T': '작동유 온도', 'T:제어반': '제어반 온도', 'P': '작동유 압력', 'PD': '차압', 'F': '작동유 유량', 'F:냉각수': '냉각수 유량',
         'V': '진동', 'J': '모터 출력', 'I': '모터 전류', 'L': '레벨'}


def value_kind(tag, row=None):
    """재는 값의 종류: 계장태그 앞 글자(ISA-5.1 첫 글자 = 재는 변수, PDT = 차압)와 매체. 계장태그가 없으면 TI-1 같은 현장 지시계 태그로 본다.
    계기 없는 계산값 · 설정값은 None(현장 메모 33행)."""
    m = re.match(r'([A-Z]+)-\d', tag or '')
    if not m:
        return None
    letters = m.group(1)
    v = 'PD' if letters.startswith('PD') else letters[0]
    if row is not None and '냉각수' in row['재는것']:
        return v + ':냉각수'
    if row is not None and v == 'T' and row['계통'] == '제어':
        return 'T:제어반'
    return v


def kind(row):
    return value_kind(row['계장태그'] or row['태그'], row)


def loop(tag):
    """계장태그 「TT-231」 → ('TT', '1'): 기능 글자와 루프 번호에서 앞 두 자리(설비)를 뺀 나머지. 3라인 도면은 끝자리를 맞추지 않았다(현장 메모 34행)."""
    m = re.fullmatch(r'([A-Z]+)-\d\d(\d+)', tag)
    return m.groups() if m else None


def same_label(a, b):
    """재는것이 같거나, 한일유압 설비끼리 태그가 같거나, 같은 라인 도면의 루프가 같다(현장 메모 33행)."""
    return (a['재는것'] == b['재는것'] or (a['제조사'] == b['제조사'] and a['태그'] == b['태그'])
            or (loop(a['계장태그']) is not None and loop(a['계장태그']) == loop(b['계장태그'])))


def kind_of(row):
    """근거: sensors.csv 비고 「계기 없음」은 계산값, 수집방식 「설정값」은 설정값, 나머지는 계기가 잰 실측."""
    if '계기 없음' in row['비고']:
        return '계산값'
    if '설정값' in row['수집방식']:
        return '설정값'
    return '실측'


def only_one(row):
    """같은 설비 · 같은 계통에 이 종류 계기가 이것 하나뿐인가."""
    return not any(value_kind(t) == kind(row) for t in row['같은_계통_계장태그'])


def same_quantity(a, b):
    """근거: 재는 값의 종류가 같고 붙은 계통도 같아야 같은 물리량. 그 계통에 같은 종류 계기가 둘 이상이면(쿨러 입구 · 출구 유온) 재는것 · 태그 · 루프로 지점을 가르고,
    하나뿐이면 같은 지점이다(탱크에 붙은 유온계 하나 = 탱크 유온)."""
    if kind(a) != kind(b) or a['계통'] != b['계통']:
        return False
    if kind(a) is None:
        return same_label(a, b)
    return same_label(a, b) or (only_one(a) and only_one(b))


def quantity_name(members):
    """근거: 묶음에서 가장 많이 쓴 재는것(같은 수면 먼저 나온 것) — 지점을 가리키는 이름."""
    names = [m['재는것'] for m in members]
    return max(names, key=lambda n: (names.count(n), -names.index(n)))
