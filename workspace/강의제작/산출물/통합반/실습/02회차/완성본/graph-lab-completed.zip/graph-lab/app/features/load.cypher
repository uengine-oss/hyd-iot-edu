// 적재 — 노드는 id로 같은 대상을 알아보고(MERGE), 값은 처음 만들 때만 넣는다(ON CREATE SET — 다시 적재해도 수정본이 고친 값을 되돌리지 않음). 관계는 양 끝 id와 관계 이름으로 알아본다.
// 넣을 것: Asset
UNWIND $rows AS row MERGE (n:Asset {id: row.id}) ON CREATE SET n = row;

// 넣을 것: INSTALLED_UNIT
UNWIND $rows AS row MATCH (a:Component {id: row.a}), (b:Unit {id: row.b}) MERGE (a)-[r:INSTALLED_UNIT]->(b) ON CREATE SET r = row.props;

// 넣을 것: USES_PART
UNWIND $rows AS row MATCH (a:Component {id: row.a}), (b:Part {id: row.b}) MERGE (a)-[r:USES_PART]->(b) ON CREATE SET r = row.props;
