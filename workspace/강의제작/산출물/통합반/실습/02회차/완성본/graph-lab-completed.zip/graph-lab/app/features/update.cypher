// 수정본 반영 — 줄은 수정본의 열 이름 그대로 받아 식별자로 찾고, 바뀐 값만 고친다. 불용 설비와 목록에서 빠진 센서는 그래프에 남겨 상태로 구별한다.
// 반영할 것: equipment_changes.csv 수정
UNWIND $rows AS row MATCH (a:Asset {id: row.설비코드}) SET a.name = row.설비명, a.status = row.상태;

// 반영할 것: sensor_changes.csv 수정
UNWIND $rows AS row MATCH (s:Sensor {id: row.설비코드 + ':' + row.태그}) SET s.normal = toFloat(row.정상값), s.limit = toFloat(row.한계);

// 반영할 것: sensor_changes.csv 삭제
UNWIND $rows AS row MATCH (s:Sensor {id: row.설비코드 + ':' + row.태그}) SET s.status = '떼어 냄';

// 반영할 것: part_alias_changes.csv 추가
UNWIND $rows AS row MATCH (p:Part {id: row.사내품번}) WHERE NOT row.다른표기 IN coalesce(p.other_codes, [])
SET p.other_codes = coalesce(p.other_codes, []) + row.다른표기;
