// 수정본 반영 — 이름이 바뀐 설비는 같은 식별자의 이름만 고치고, 불용 결정 설비는 그래프에 남겨 상태로 구별한다.
MATCH (a:Asset {id: 'HYD-02'}) SET a.name = 'HYD-02 2라인 2호 파워팩';
MATCH (a:Asset {id: 'HYD-07'}) SET a.status = '불용(매각 예정)';
