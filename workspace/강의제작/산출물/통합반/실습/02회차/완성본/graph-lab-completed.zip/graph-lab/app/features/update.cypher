// 수정본 반영 — 불용 결정 설비는 대장에 남기고 상태로 구별(equipment_changes.csv 3줄), 이름 표준화(2줄), 값 보완(sensor_changes.csv 2 · 3줄),
// 교체부품 확인 · 변경(component_changes.csv 2 · 3줄 — 3줄은 잇는 부품이 바뀌므로 옛 관계를 지우고 새로 잇는다). sensor_changes.csv 4줄 「삭제」는 같은 센서를 점검표에서 옮겨 적은 중복 행 정리라 그래프의 센서는 그대로 둔다.
MATCH (a:Asset {id: 'HYD-02'}) SET a.name = 'HYD-02 2라인 2호 파워팩';
MATCH (a:Asset {id: 'HYD-07'}) SET a.status = '불용(매각 예정)';
MATCH (s:Sensor {id: 'HYD-03:VS1'}) SET s.unit = 'mm/s', s.normal = 0.6;
MATCH (s:Sensor {id: 'HYD-06:I_MOTOR'}) SET s.unit = 'A', s.normal = 18.5;
MATCH (c:Component {id: 'HYD-03:pump-a'}), (p:Part {id: 'P-PMP-SEAL'}) MERGE (c)-[u:USES_PART]->(p) SET u.source_text = 'P-PMP-SEAL';
MATCH (c:Component {id: 'HYD-03:rtn-filter'})-[u:USES_PART]->(p:Part) WHERE p.id <> 'P-RTN-FLT-25' DELETE u;
MATCH (c:Component {id: 'HYD-03:rtn-filter'}), (p:Part {id: 'P-RTN-FLT-25'}) MERGE (c)-[u:USES_PART]->(p) SET u.source_text = 'P-RTN-FLT-25';
