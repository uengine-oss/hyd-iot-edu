// 질문 1 — 설비 하나의 구성 요소별 센서(설비에 바로 붙은 센서는 「(설비 전체)」)
MATCH (a:Asset {id: $asset})-[:HAS_COMPONENT*0..1]->(x)-[:MONITORED_BY]->(s:Sensor)-[:OBSERVES]->(q:Quantity)
RETURN CASE WHEN x = a THEN '(설비 전체)' ELSE x.id END AS attached_to, s.id AS sensor, s.tag AS tag, s.kind AS kind,
       q.name AS quantity, s.unit AS unit, s.normal AS normal, s.limit AS limit, s.limit_direction AS direction
ORDER BY attached_to, tag;

// 질문 2 — 설비 하나의 구성 요소마다 교체 부품(없으면 빈 칸으로 남김)
MATCH (a:Asset {id: $asset})-[:HAS_COMPONENT]->(c:Component)
OPTIONAL MATCH (c)-[:USES_PART]->(p:Part)
RETURN c.id AS component, c.name AS component_name, p.id AS part, p.name AS part_name
ORDER BY component;

// 질문 3 — 품번이나 다른 표기로 부품을 찾고 쓰는 설비 · 구성 요소와 설비 상태(가동이 아닌 설비도 상태와 함께)
OPTIONAL MATCH (p:Part) WHERE p.id = $part OR $part IN coalesce(p.other_codes, [])
OPTIONAL MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)-[:USES_PART]->(p)
RETURN p.id AS part, a.id AS asset, a.status AS status, c.id AS component,
       CASE WHEN p IS NULL THEN '원자료에 없는 품번' WHEN a IS NULL THEN '쓰는 설비 없음' END AS note
ORDER BY part, asset, component;
