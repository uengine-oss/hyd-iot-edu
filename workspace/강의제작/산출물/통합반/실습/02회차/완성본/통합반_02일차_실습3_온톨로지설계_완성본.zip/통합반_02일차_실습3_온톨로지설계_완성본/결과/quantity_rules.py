# 제공 빈 틀 — 같은 물리량과 센서 종류를 가르는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.
import re


def loop(tag):
    """계장태그 「TT-231」 → ('TT', '1'): 재는 기능 글자와, 루프 번호에서 앞 두 자리(설비)를 뺀 나머지(현장 메모 35행)."""
    m = re.fullmatch(r'([A-Z]+)-\d\d(\d+)', tag)
    return m.groups() if m else None


def same_quantity(a, b):
    """근거: 재는것이 같으면 같은 물리량. 현장 메모 35행 — 한일유압 설비는 같은 태그 이름, 계장태그는 기능 글자와 루프가 같으면 같은 것을 잰다."""
    if a['재는것'] == b['재는것']:
        return True
    if a['제조사'] == b['제조사'] and a['태그'] == b['태그']:
        return True
    return loop(a['계장태그']) is not None and loop(a['계장태그']) == loop(b['계장태그'])


def quantity_name(members):
    """근거: 묶음에서 가장 많이 쓴 재는것(같은 수면 센서 목록에서 먼저 나온 것)."""
    names = [m['재는것'] for m in members]
    return max(names, key=lambda n: (names.count(n), -names.index(n)))


def kind_of(row):
    """근거: 센서_목록.csv 비고 「계기 없음」은 계산값, 수집방식 「설정값」은 설정값, 나머지는 계기가 잰 실측."""
    if '계기 없음' in row['비고']:
        return '계산값'
    if '설정값' in row['수집방식']:
        return '설정값'
    return '실측'
