# 실행 결과

모델실행.py가 자료를 읽어 schema.json, graph.json과 질문별_결과.json을 만듭니다. 명령을 실행할 때마다 이 세 파일을 다시 작성합니다.
