// 수정본 반영 — 불용 결정 설비는 대장에 남기고 상태로 구별(설비_대장_변경.csv 3줄), 이름 표준화(2줄), 값 보완(센서_변경.csv 2 · 3줄),
// 교체부품 확인(구성요소_변경.csv 2줄). 센서_변경.csv 4줄 「삭제」는 같은 센서를 점검표에서 옮겨 적은 중복 행 정리라 그래프의 센서는 그대로 둔다.
MATCH (a:Asset {id: 'HYD-02'}) SET a.name = 'HYD-02 2라인 2호 파워팩';
MATCH (a:Asset {id: 'HYD-07'}) SET a.status = '불용(매각 예정)';
MATCH (s:Sensor {id: 'HYD-03:VS1'}) SET s.unit = 'mm/s', s.normal = 0.6;
MATCH (s:Sensor {id: 'HYD-06:I_MOTOR'}) SET s.unit = 'A', s.normal = 18.5;
MATCH (c:Component {id: 'HYD-03:pump-a'}), (p:Part {id: 'P-PMP-SEAL'}) MERGE (c)-[u:USES_PART]->(p) SET u.source_text = 'P-PMP-SEAL';
