// queries/part_assets.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)-[:USES_PART]->(p:Part)
WHERE (p.id = $part OR $part IN coalesce(p.other_codes, [])) AND a.status = '가동'
RETURN p.id AS part, a.id AS asset, c.id AS component, c.name AS component_name ORDER BY asset, component;

// queries/sensor_quantities.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)-[:MONITORED_BY]->(s:Sensor)-[:OBSERVES]->(q:Quantity)
WHERE $quantity = '' OR q.name = $quantity
RETURN a.id AS asset, c.id AS component, s.id AS sensor, s.tag AS tag, s.kind AS kind, q.name AS quantity, s.unit AS unit, s.normal AS normal, s.limit AS limit, s.limit_direction AS direction ORDER BY asset,component,sensor;

// queries/asset_counts.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)
OPTIONAL MATCH (c)-[:MONITORED_BY]->(s:Sensor)
RETURN a.id AS asset, count(DISTINCT c) AS components, count(DISTINCT s) AS sensors ORDER BY asset;
