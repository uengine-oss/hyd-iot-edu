// queries/part_assets.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)-[:USES_PART]->(p:Part)
WHERE (p.id = $part OR $part IN coalesce(p.other_codes, [])) AND a.status = '가동'
RETURN p.id AS part, a.id AS asset, c.id AS component, c.name AS component_name ORDER BY asset, component;

// queries/asset_sensors.cypher
MATCH (a:Asset)-[:HAS_COMPONENT*0..1]->(x)-[:MONITORED_BY]->(s:Sensor)-[:OBSERVES]->(q:Quantity)
WHERE $asset = '' OR a.id = $asset
RETURN a.id AS asset, CASE WHEN x = a THEN '(설비 전체)' ELSE x.id END AS attached_to, s.id AS sensor, s.tag AS tag, s.kind AS kind, q.name AS quantity, s.unit AS unit, s.normal AS normal, s.limit AS limit, s.limit_direction AS direction ORDER BY asset, attached_to, sensor;

// queries/asset_parts.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)
WHERE $asset = '' OR a.id = $asset
OPTIONAL MATCH (c)-[:USES_PART]->(p:Part)
RETURN a.id AS asset, c.id AS component, c.name AS component_name, p.id AS part, p.name AS part_name ORDER BY asset, component;

// queries/asset_counts.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)
OPTIONAL MATCH (c)-[:MONITORED_BY]->(s:Sensor)
RETURN a.id AS asset, count(DISTINCT c) AS components, count(DISTINCT s) AS sensors ORDER BY asset;
