// queries/part_assets.cypher
OPTIONAL MATCH (p:Part) WHERE p.id = $part OR $part IN coalesce(p.other_codes, [])
OPTIONAL MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)-[:USES_PART]->(p) WHERE a.status = '가동'
OPTIONAL MATCH (x:Asset)-[:HAS_COMPONENT]->(:Component)-[:USES_PART]->(p) WHERE x.status <> '가동'
WITH p, a, c, collect(DISTINCT x.id + ' ' + x.status) AS not_running
RETURN p.id AS part, a.id AS asset, c.id AS component, c.name AS component_name,
       CASE WHEN p IS NULL THEN '원자료에 없는 품번' WHEN a IS NULL THEN '지금 가동하는 설비에서는 쓰지 않음' END AS note,
       not_running ORDER BY part, asset, component;

// queries/asset_sensors.cypher
MATCH (a:Asset)-[:HAS_COMPONENT*0..1]->(x)-[:MONITORED_BY]->(s:Sensor)-[:OBSERVES]->(q:Quantity)
WHERE $asset = '' OR a.id = $asset
RETURN a.id AS asset, CASE WHEN x = a THEN '(설비 전체)' ELSE x.id END AS attached_to, s.id AS sensor, s.tag AS tag, s.kind AS kind, q.id AS quantity_id, q.name AS quantity, s.unit AS unit, s.normal AS normal, s.limit AS limit, s.limit_direction AS direction ORDER BY asset, attached_to, sensor;

// queries/asset_parts.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)
WHERE $asset = '' OR a.id = $asset
OPTIONAL MATCH (c)-[:USES_PART]->(p:Part)
RETURN a.id AS asset, c.id AS component, c.name AS component_name, p.id AS part, p.name AS part_name ORDER BY asset, component;

// queries/asset_counts.cypher
MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)
OPTIONAL MATCH (c)-[:MONITORED_BY]->(s:Sensor)
RETURN a.id AS asset, count(DISTINCT c) AS components, count(DISTINCT s) AS sensors ORDER BY asset;
