"""제공 빈 틀입니다. 보관하지 말고 바로 채웁니다 — START.md 「학생이 정할 것」의 빈 값의 뜻.

팬 운전 카운터의 정해진 주기 기록이 판정 요청 전에 끊긴 경보마다 제공 코드 judge_tools.py가 이 함수를 부릅니다.
ctx(읽기만): alarm_id 경보 ID · asset 설비 · decision_time 판정 요청 시각(UTC 글자) ·
  counter_last 판정 요청 전 마지막 카운터 기록(팬_운전_카운터.csv의 칸 이름 그대로 + '줄' 줄 번호) · counter_age_min 그 기록에서 판정 요청까지 지난 분 · counter_period_min 주기 기록 간격(분) ·
  plc_last 판정 요청 전 마지막 PLC 상태 수신(PLC_상태_수신.csv의 칸 이름 그대로 + '줄', 없으면 None) · plc_reason 운전 모드 · 상태를 값 없음으로 둔 까닭(값이 있으면 None)
돌려줄 값: (팬 100 % 연속 시간 h — 숫자 또는 None, None이면 값이 없는 까닭 글 · 숫자면 None)
"""


def fan_hours_when_gap(ctx):
    # 판정 요청 때 PLC가 정상 수신(품질 good, 하트비트 안)이고 팬 설정이 100 %면 그 사이 100 % 운전이 이어졌다고 본다
    # 근거: 자료/수집_설명.md 26줄(행 사이에도 센다 — 이어졌을 때 누적 분 + 지난 시간), PLC_상태_수신.csv 팬_설정_pct
    if ctx.plc_reason is None and ctx.plc_last is not None and float(ctx.plc_last['팬_설정_pct']) == 100.0:
        return (float(ctx.counter_last['팬100_연속_분']) + ctx.counter_age_min) / 60, None
    return None, 'PLC 팬 설정으로도 100 %를 확인하지 못함'
