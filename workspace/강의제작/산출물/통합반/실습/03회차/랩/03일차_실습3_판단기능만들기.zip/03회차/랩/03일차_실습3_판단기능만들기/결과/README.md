﻿이번 과제의 정할 자리(빈 함수 둘 · 정한 것 · 기대 판정 · 기대결과)를 채우는 자리입니다. `python show_result.py`가 `result.json`와 결과 화면 `보기.html`을 여기에 씁니다.
