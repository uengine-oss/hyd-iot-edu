# 제공 참조

수업 시나리오 A 「냉각 긴급 대응」의 제공 기준 BPMN(`cooling-emergency.bpmn`)과 연결 값(`mapping.json`), 구조 그림(`flow.svg`)입니다. BPMN·매핑은 저장소 `students/flows/`의 같은 이름 파일(`cooling-emergency.bpmn`, `cooling-emergency.mapping.json`)을 그대로 복사했고, 포털에 등록된 수업 흐름 「냉각 긴급 대응」과 같은 모양·같은 연결 값으로 관리됩니다. `flow.svg`의 글자 라벨은 이론 교재와 함께 읽습니다. 내 그림과 견주는 대조용이며 고치거나 내 결과 대신 쓰지 않습니다.

BPMN 그림 파일에는 요소·선·레인과 이름만 있습니다. 승인·회복 분기의 실행 조건, 승인 지연 기한 `PT10M`, 작업마다 붙는 실행 기능(부품)·에이전트·역할은 `mapping.json`의 `tasks`·`flows`·`timers`에 있습니다. 선 이름만으로 실행 조건이 생기지 않습니다.
