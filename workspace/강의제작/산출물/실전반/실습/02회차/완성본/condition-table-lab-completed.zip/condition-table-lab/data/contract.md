﻿# 입출력 계약

결과 파일의 형식과 뜻만 정한다. 무엇을 담을지는 원문에서 정한다.

## 조건표 (`app/features/condition_table.csv`)

3회차 조치 검토 결과 실습의 판정 기능이 조건표를 이 꼴 그대로 읽는다. 열 이름을 바꾸면 그 기능이 읽지 못한다. 이 문서는 형식과 뜻만 정하고, 어떤 조건을 어느 조치에 걸지는 원문에서 정한다. 첫머리의 `#` 줄(「제공 빈 틀」 표시)은 데이터가 아니다.

열: `rule_id,action,condition_index,logic,input,operator,value,unit,boundary_included,result,penalty_manwon,reason,source_section`

- 비교 하나가 한 행이다. 같은 `rule_id` · `action`의 행은 한 규칙 묶음이고 `condition_index`를 1부터 차례로 적으며 `logic`은 `AND`다. OR는 다른 `rule_id`로 나눈다.
- `action`: `data/targets.csv`의 SOP ID 하나. 같은 규칙을 여러 조치에 걸면 조치마다 묶음 전체를 적는다. 표에 없는 조치 · 규칙 조합은 그 조치에 그 규칙을 걸지 않는다는 뜻이다.
- `result`: `WARN`(경고) · `PENALTY`(감점) · `EXCLUDE`(제외). 같은 묶음의 `result` · `penalty_manwon` · `reason` · `source_section`은 모든 행에서 같다. `PENALTY`만 `penalty_manwon`(만원)을 적고 나머지는 빈칸이다.
- `operator`: `>=` · `>` · `<=` · `<` · `==` · `!=` · `has_other_than`(목록 입력에 기준값이 아닌 항목이 하나라도 있음). `boundary_included`: 기준값 자체가 조건에 들어가면 `예`, 들어가지 않으면 `아니오`, 글자 · 목록 비교는 `해당없음`.
- `input`과 단위: `forecast_ts1`(조치 후 예측 유온, ℃) · `forecast_ps1`(조치 후 예측 토출 압력, bar) · `fan100_hours`(팬 100 % 연속 운전 시간, h) · `plc_mode`(`REMOTE_AUTO` · `REMOTE_MANUAL` · `LOCAL`) · `plc_state`(`RUN` · `TRIP` · `STOP`) · `skill_kind`(조치 종류 `control` · `work_order`) · `skill_code`(실행 코드 목록). `skill_kind` · `skill_code` 값이 오는 곳: `targets.csv`의 `kind` · `codes`. 숫자 입력은 `unit`을 적는다.
- 목록 입력(`skill_code`)에는 `has_other_than`만 쓴다.
- `source_section`: 이 행의 근거를 다른 사람이 다시 찾을 수 있게 적는다 — HM-8 매뉴얼 원문의 근거는 절 · SOP 단계 · 승인 줄을 ;로 잇고 문서 이름 · 판은 붙이지 않는다(꼴: HM-8.<절>; HM-8.<절> SOP-<ID> 단계 <n>; HM-8.<절> SOP-<ID> 승인), 자료 파일의 줄은 파일:줄, 결정표에서 가져온 행은 「판단 시스템 결정표 rule:<id>; 출처 <그 규칙의 출처>」 뒤에 HM-8 매뉴얼 원문에서 그 출처를 찾았는지를 적고, 결정표 규칙을 고쳐 HM-8 매뉴얼 원문 근거로 옮긴 행은 원문 출처 뒤에 「판단 시스템 결정표 rule:<id>」를 덧붙인다(결과 화면은 rule:<id>가 있어야 그 규칙을 출처로 든 것으로 읽는다).

모양을 보이는 한 줄(이 과제의 규칙이 아니다):

```
R0,SOP-COOL-00,1,AND,forecast_ts1,>=,0,℃,예,WARN,,이유 문장,문서 절
```

## 승인 (`app/features/approvals.csv` — 「제공 빈 틀」)

열 `sop_id,승인_역할,원문`. 후보마다 한 줄. `원문`은 `data/hm8_manual.md`의 승인 근거 줄 번호(`68` 또는 `data/hm8_manual.md:68`, `;`로 나눔, 찾지 못했으면 찾아본 절의 줄과 함께 `승인_역할`을 `미확인`으로 시작).

## 고른 것 (`app/features/decisions.csv`) · 기대 판정 (`app/features/expected.csv`)

- `app/features/decisions.csv` — 열 `지점,고른_것,근거,바뀌는_답`. 칸마다 뜻은 그 파일 첫머리 `#` 줄에 있다. 같은 종류의 지점이 여럿이면 지점마다 한 줄.
- `app/features/expected.csv` — 열 `사례,후보,기대_판정,근거`. `사례`는 `data/check_cases.csv`의 사례 ID(사건 메모의 경보도 그 ID). 제공 코드를 돌리기 전에 원자료 · 조건표 · 원문으로 손으로 구한 기대. `기대_판정`은 `유지` · `제외` · `보류`(뜻은 `data/work_standard.md` 4절), `근거`는 `파일:줄`.

## 확인 사례 (`data/check_cases.csv`, 읽기만)

열: `사례,설비,판정_요청_시각,후보,입력,값,단위,원천,원천_시각,비고`. 한 줄이 사례 하나의 판단 입력 하나다.

- `값`은 판정을 요청한 때(`판정_요청_시각`)의 판단 입력이고 단위는 `단위` 칸이다. 조건표 `input`과의 짝: `운전_모드` = `plc_mode`, `상태` = `plc_state`,
  `팬100_연속` = `fan100_hours`(판정 요청 때까지 팬 100 % 연속 운전 시간, h), `예측_TS1` = `forecast_ts1`(℃), `예측_PS1` = `forecast_ps1`(bar).
- `후보`가 빈칸인 줄은 그 사례의 모든 후보에 같은 입력이다. `skill_kind` · `skill_code`는 이 파일에 없다 — 값이 오는 곳은 조건표 절의 `input` 설명과 같다.
- `값`이 빈칸이면 그 입력을 얻지 못한 것이고, `비고`에 원천의 사정이 있다.
- `원천` · `원천_시각`은 그 값을 만든 기록과 그 기록의 시각이다.
