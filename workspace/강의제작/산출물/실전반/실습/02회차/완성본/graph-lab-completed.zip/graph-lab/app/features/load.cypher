// 내 적재 쿼리 — 설비는 원자료 표의 줄을 스키마대로 옮기고(식별자로 같은 대상을 알아보는 MERGE, 값은 처음 만들 때만), 관계는 양 끝을 레이블과 식별자로 찾아 잇는다.
// 넣을 것: Asset
UNWIND $rows AS row MERGE (n:Asset {id: row.설비코드}) ON CREATE SET n.code = row.설비코드, n.name = row.설비명, n.model = row.모델, n.status = row.상태, n.maker = row.제조사, n.serial = row.일련번호, n.functional_location = row.기능위치, n.installed = row.설치일;

// 넣을 것: HAS_COMPONENT
UNWIND $rows AS row MATCH (a:Asset {id: row.a}), (b:Component {id: row.b}) MERGE (a)-[r:HAS_COMPONENT]->(b);

// 넣을 것: USES_PART
UNWIND $rows AS row MATCH (a:Component {id: row.a}), (b:Part {id: row.b}) MERGE (a)-[r:USES_PART]->(b) ON CREATE SET r.source_text = row.props.source_text;

// 넣을 것: OFFERS
UNWIND $rows AS row MATCH (a:Supplier {id: row.a}), (b:Quote {id: row.b}) MERGE (a)-[r:OFFERS]->(b);

// 넣을 것: QUOTES_PART
UNWIND $rows AS row MATCH (a:Quote {id: row.a}), (b:Part {id: row.b}) MERGE (a)-[r:QUOTES_PART]->(b);
