// 제공 적재 쿼리 — Component · Part · Quantity · Quote · Sensor · Supplier · Unit · ASSET_MONITORED_BY · INSTALLED_UNIT · MONITORED_BY · OBSERVES. python run.py load가 내 쿼리(app/features/load.cypher)와 함께 실행한 것입니다. 이 파일은 실행할 때마다 다시 쓰입니다.

// 넣을 것: Component
UNWIND $rows AS row MERGE (n:`Component` {id: row.id}) ON CREATE SET n = row;

// 넣을 것: Part
UNWIND $rows AS row MERGE (n:`Part` {id: row.id}) ON CREATE SET n = row;

// 넣을 것: Quantity
UNWIND $rows AS row MERGE (n:`Quantity` {id: row.id}) ON CREATE SET n = row;

// 넣을 것: Quote
UNWIND $rows AS row MERGE (n:`Quote` {id: row.id}) ON CREATE SET n = row;

// 넣을 것: Sensor
UNWIND $rows AS row MERGE (n:`Sensor` {id: row.id}) ON CREATE SET n = row;

// 넣을 것: Supplier
UNWIND $rows AS row MERGE (n:`Supplier` {id: row.id}) ON CREATE SET n = row;

// 넣을 것: Unit
UNWIND $rows AS row MERGE (n:`Unit` {id: row.id}) ON CREATE SET n = row;

// 넣을 것: ASSET_MONITORED_BY
UNWIND $rows AS row MATCH (a:`Asset` {id: row.a}), (b:`Sensor` {id: row.b}) MERGE (a)-[r:`ASSET_MONITORED_BY`]->(b) ON CREATE SET r += row.props;

// 넣을 것: INSTALLED_UNIT
UNWIND $rows AS row MATCH (a:`Component` {id: row.a}), (b:`Unit` {id: row.b}) MERGE (a)-[r:`INSTALLED_UNIT`]->(b) ON CREATE SET r += row.props;

// 넣을 것: MONITORED_BY
UNWIND $rows AS row MATCH (a:`Component` {id: row.a}), (b:`Sensor` {id: row.b}) MERGE (a)-[r:`MONITORED_BY`]->(b) ON CREATE SET r += row.props;

// 넣을 것: OBSERVES
UNWIND $rows AS row MATCH (a:`Sensor` {id: row.a}), (b:`Quantity` {id: row.b}) MERGE (a)-[r:`OBSERVES`]->(b) ON CREATE SET r += row.props;
