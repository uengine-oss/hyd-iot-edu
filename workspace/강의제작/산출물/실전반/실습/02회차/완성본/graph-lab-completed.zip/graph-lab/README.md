﻿# 부품의 사용 설비와 공급 정보를 조회하는 그래프 구현하기 · 완성본

AI 계정이 없거나 구현 중 막혔을 때 실행해 보는 묶음입니다. 판단 기준 한 가지를 적용했으며 선택과 근거는 app/features/decisions.csv에 있습니다. Docker Desktop을 켠 뒤 실행합니다.

```text
data/           실습 자료
app/features/   AI와 구현할 핵심 기능
app/ui/         결과 화면 — 제공
app/utils/      공통 처리 — 제공
output/         실행 후 생기는 결과
AGENTS.md       AI가 지킬 공통 규칙
```

실행:

```text
python run.py db
python run.py load
python run.py usage
```
