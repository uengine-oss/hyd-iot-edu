// 질문 1 — 설비 하나의 구성 요소별 센서
MATCH (a:Asset {code: $asset})-[:HAS_COMPONENT]->(c:Component)-[:MONITORED_BY]->(s:Sensor)-[:OBSERVES]->(q:Quantity)
RETURN c.name AS component, s.tag AS tag, q.name AS quantity,
       s.unit AS unit, s.normal AS normal, s.limit AS limit, s.limit_direction AS direction, s.status AS status
ORDER BY component, tag;

// 질문 2 — 설비 하나의 구성 요소마다 교체 부품(없으면 빈 칸으로 남김)
MATCH (a:Asset {code: $asset})-[:HAS_COMPONENT]->(c:Component)
OPTIONAL MATCH (c)-[:USES_PART]->(p:Part)
RETURN c.name AS component, p.part_no AS part, p.name AS part_name
ORDER BY component;

// 질문 3 — 품번이나 다른 표기로 부품을 찾고 쓰는 설비 · 구성 요소와 설비 상태
OPTIONAL MATCH (p:Part) WHERE p.part_no = $part OR $part IN coalesce(p.other_codes, [])
OPTIONAL MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)-[:USES_PART]->(p)
RETURN p.part_no AS part, a.code AS asset, a.status AS status, c.name AS component,
       CASE WHEN p IS NULL THEN '원자료에 없는 품번' WHEN a IS NULL THEN '쓰는 설비 없음' END AS note
ORDER BY part, asset, component;

// 질문 4 — 품번이나 다른 표기로 부품을 찾고, 기준일에 유효기한이 남은 견적을 낸 공급사와 그 조건 · 근거 줄
OPTIONAL MATCH (p:Part) WHERE p.part_no = $part OR $part IN coalesce(p.other_codes, [])
OPTIONAL MATCH (s:Supplier)-[:OFFERS]->(q:Quote)-[:QUOTES_PART]->(p) WHERE q.valid_until >= date('2026-10-15')
RETURN p.part_no AS part, s.name AS supplier, q.approval AS approval, q.price_manwon AS price, q.defect_rate AS defect_rate, q.lead_days AS lead_days,
       q.quote_date AS quote_date, q.quote_source AS quote_source, q.approval_source AS approval_source,
       CASE WHEN p IS NULL THEN '원자료에 없는 품번' WHEN q IS NULL THEN '기준일에 유효한 견적 없음' END AS note
ORDER BY supplier, quote_date;
