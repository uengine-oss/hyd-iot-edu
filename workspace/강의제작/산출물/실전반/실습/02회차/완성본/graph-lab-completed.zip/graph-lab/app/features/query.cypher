// 질문 1 — 부품 하나의 사용 설비 · 구성 요소와 공급사마다 공급 조건(승인 상태 · 출처, 구매 기준서 7.4 정보 포함)
OPTIONAL MATCH (p:Part) WHERE p.id = $part OR $part IN coalesce(p.other_codes, [])
OPTIONAL MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component)-[:USES_PART]->(p)
WITH p, collect(DISTINCT a.id) AS assets, collect(DISTINCT c.id) AS components
OPTIONAL MATCH (s:Supplier)-[r:SUPPLIES]->(p)
RETURN p.id AS part, assets, components, s.name AS supplier, r.approved AS approved, r.approval_status AS approval_status, r.condition AS condition,
       r.price_manwon AS price_manwon, r.defect_rate AS defect_rate, r.lead_days AS lead_days,
       r.inspection AS inspection, r.compare_extra_manwon AS compare_extra_manwon, r.rule_source AS rule_source,
       r.quote_source AS quote_source, r.quote_date AS quote_date, r.approval_source AS approval_source, r.as_of AS as_of
ORDER BY supplier;

// 질문 2 — 정식 품번 · 예전 품번 · 다른 표기로 같은 부품을 찾고, 없는 품번은 한 줄로 알림(비슷한 이름은 합치지 않음)
OPTIONAL MATCH (p:Part) WHERE p.id = $part OR $part IN coalesce(p.other_codes, [])
OPTIONAL MATCH (s:Supplier)-[r:SUPPLIES]->(p)
RETURN p.id AS part, CASE WHEN p IS NULL THEN '원자료에 없는 품번' WHEN p.id = $part THEN '정식 품번' ELSE '다른 표기' END AS found_by,
       s.name AS supplier, r.approved AS approved, r.approval_status AS approval_status
ORDER BY part, supplier;
