# 제공 빈 틀 — 기준일에 쓸 견적을 고르는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.


def use_quote(quotes, as_of):
    """근거: 자료/현장_메모.md 6절(견적을 쌓아 둔 표), 공급_조건.csv 유효기한 칸 — 기준일에 기한이 지난 견적은 쓰지 않고, 남은 것 가운데 견적일이 가장 늦은 줄."""
    live = [q for q in quotes if q['유효기한'] >= as_of]
    return max(live, key=lambda q: q['견적일']) if live else None
