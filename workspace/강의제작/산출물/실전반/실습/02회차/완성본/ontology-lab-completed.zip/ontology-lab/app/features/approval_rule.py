# 제공 빈 틀 — 승인과 구매 담당이 함께 볼 것을 담는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.


def approval(entry, as_of):
    """근거: data/purchasing_standard_pr07.md 7.3(승인 여부는 SCM 등록을 따른다), approved_suppliers.csv 유효기한 칸."""
    if entry is None:
        return {'approved': False, 'approval_status': '미등록'}
    status = entry['승인상태']
    if entry['유효기한'] and entry['유효기한'] < as_of:
        status = '유효기한 경과'
    out = {'approved': status in ('승인', '조건부 승인'), 'approval_status': status}
    if entry['조건']:
        out['condition'] = entry['조건']
    return out


def buyer_info(pair):
    """근거: purchasing_standard_pr07.md 28행(7.4) — 불량률이 10 %를 넘는 승인 공급사는 입고 전수 검사, 비교 때 20만 원을 더함"""
    if pair['approved'] and round(pair['defect_rate'] * 100, 6) > 10:
        return {'inspection': '입고 전수 검사', 'compare_extra_manwon': 20.0, 'rule_source': 'purchasing_standard_pr07.md 28행(7.4)'}
    return {}
