# 제공 빈 틀 — 기준일에 쓸 견적을 고르는 내 판단. 함수 머리와 설명은 그대로 두고 본문만 채웁니다.


def use_quote(quotes, as_of):
    """근거: supply_terms.csv 유효기한 칸 — 기준일에 기한이 지난 견적은 쓰지 않는다. 유효한 줄이 둘 이상이면 decisions.csv 「기준일에 유효한 견적이 여럿인 쌍」대로 견적일이 가장 늦은 줄(새 견적이 앞 견적을 대신함)."""
    live = [q for q in quotes if q['유효기한'] >= as_of]
    if len(live) <= 1:
        return live[0] if live else None
    return max(live, key=lambda q: q['견적일'])
