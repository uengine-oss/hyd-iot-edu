﻿# 작업 기준의 복합 조건과 예외를 조치 조건표로 표현하기

포털 판단 규칙 화면에서 본 허용 · 제외의 근거를 Codex와 함께 HM-8 매뉴얼 원문에서 찾아 조치 조건표로 만듭니다. 판단 시스템에 등록된 결정표와 줄마다 출처를 견줍니다.

```text
data/           실습 자료
app/features/   AI와 구현할 핵심 기능
app/ui/         결과 화면 — 제공
app/utils/      공통 처리 — 제공
output/         실행 후 생기는 결과
AGENTS.md       AI가 지킬 공통 규칙
```

실행: `python run.py`
